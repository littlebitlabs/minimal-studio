# Branding Assets

The app reads two PNG files from here. Their names are set in `frontend/src/config/branding.ts`:

- `logo-minimal.png`   → the Minimal Studio mark in the Sidebar (top-left product brand)
- `logo-littlebit.png` → the Littlebit Labs mark: the company chip in the TopBar (right side), the mark beside the title on the sign-in pages, and the Conversation assistant's avatar

`logo-littlebit.png` is the company's triple spiral in brushed metal (512×512, transparent background; in use since 2026-11-13).

Not used by the app, and kept: `old-company-logo.png` and `old-product-logo.png` (the Wails starter's placeholder), `old-logo-littlebit.svg` (the company's previous mark) and `logo minimal.svg` (the Studio's mark as a vector). The `old-` prefix says that the first three are retired.

Recommended PNG setup:

- Transparent background
- Square canvas (at least 256x256)
- Padding around mark to avoid edge clipping
